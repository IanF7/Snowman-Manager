import java.time.LocalDate

// SnowMan class that contains an id, name, whether or not it has a top hat, date of birth, and weight
class SnowMan(val id: Int, val name: String, val hasTopHat: Boolean, val dateOfBirth: LocalDate, val weightKG: Float)
{
    // Returns all information relating to the snowman
    fun getAllInfo(): String
    {
        return "SnowMan $id:\n" +
                "\tName= $name\n" +
                "\tHas a Top Hat= $hasTopHat\n" +
                "\tDate of Birth= $dateOfBirth\n" +
                "\tWeight= $weightKG\n"
    }

    // Returns just the name and id of the snowman
    fun getNameAndID(): String
    {
        return "Snowman ID: $id\t Snowman Name: $name\n"
    }
}

// Main function
fun main(args: Array<String>)
{
    // Creates snowman "Frosty" and saves it to man1
    val man1 = SnowMan(1, "Frosty", false, LocalDate.parse("1952-12-25"), 88.1F)
    println(man1)

    // Creates snowMenList mutable list and adds man1 to it
    var snowMenList = mutableListOf<SnowMan>()
    snowMenList.add(man1)

    // Creates userChoice variable to track user input
    var userChoice = 0

    // Runs while userChoice is not equal to 9
    while(userChoice != 9)
    {
        // Displays options and reads in user input
        println("please choose an option:")
        println("1.\tAdd a new snowman to the inventory\n" +
                "2.\tDisplay all snowmen in the inventory\n" +
                "3.\tShow a single snowman given its id number\n" +
                "4.\tSearch for a snowman by (partial) name\n" +
                "5.\tDelete a snowman\n" +
                "6.\tChange a snowman\n" +
                "9.\tQuit the program\n")
        println()
        userChoice = Integer.parseInt(readLine())
        println()

        // Has different outcomes based on user input
        when(userChoice)
        {
            // When user enters 1
            1 -> {
                // Reads in name and if name is blank leaves it as Unknown
                println("Enter new snowman name:")
                val newName = readLine()?.takeIf { it.isNotBlank() } ?: "Unknown"

                // Reads in whether or not snowman has a hat and if it is blank leaves it as false
                println("Enter 'true' if the new snowman has a top hat and 'false' if not:")
                val newHasTopHat = readLine()?.toBooleanStrictOrNull() ?: false

                // Reads in date of birth and if it is blank or is in the wrong format leaves it as 2000-01-01
                println("Enter the new snowman's date of birth in the format YYYY-MM-DD:")
                val newDateOfBirth = try {
                    LocalDate.parse(readLine())
                } catch (e: Exception) {
                    println("Invalid date format. Using default date of 2000-01-01.")
                    LocalDate.parse("2000-01-01")
                }

                // Reads in weight and if it is blank leaves it as 0.0
                println("Enter the new snowman's weight in kilograms:")
                val newWeightKG = readLine()?.toFloatOrNull() ?: 0.0F

                // Creates new snowman and adds it at end of the list
                val newSnowman = SnowMan(snowMenList.size + 1, newName, newHasTopHat, newDateOfBirth, newWeightKG)
                snowMenList.add(newSnowman)
            }
            // When user enters 2
            2 -> {
                // Checks if list is empty and prints out that there are no snowmen if so
                if (snowMenList.isEmpty())
                {
                    println("No snowmen in the inventory.")
                }
                // Otherwise uses for loop to print out info for all snowmen
                else
                {
                    println("Displaying all snowmen:")
                    for (snowman in snowMenList)
                    {
                        println(snowman.getAllInfo())
                    }
                }
                println()
            }
            // When user enters 3
            3 -> {
                // If the list isn't empty
                if(snowMenList.isNotEmpty())
                {
                    // Prompts user to enter the id of the snowman the user wants to view
                    println("Enter ID of snowman you want to view:")
                    var snowmanId = 0
                    var foundSnowman = false
                    snowmanId = Integer.parseInt(readLine())

                    // Goes through every snowman in snowMenList and checks if the ids match and if so prints all info on that snowman
                    for(snowman in snowMenList)
                    {
                        if(snowmanId == snowman.id)
                        {
                            println(snowman.getAllInfo())
                            foundSnowman = true
                            break
                        }
                    }

                    // If a snowman with the id is not found, prints out that none were found
                    if(!foundSnowman)
                    {
                        println("No snowman was found with that id.\n")
                    }
                }
                // If the list is empty, prints out that no snowmen exist
                else
                {
                    println("No snowman current exist.\n")
                }
            }
            // When the user enters 4
            4 -> {
                // Prompts user to enter name of snowman they want to view
                println("Enter the name of the snowman you want to view:\n")
                val enteredName = readLine()

                // Checks every snowman's name to see if it has the string the user entered in it or is what the user entered in
                // and if so prints out all info on the given snowman/snowmen
                for(snowman in snowMenList)
                {
                    if(enteredName?.let { snowman.name.contains(it) } == true || snowman.name == enteredName)
                    {
                        println(snowman.getAllInfo())
                    }
                }
            }
            // When the user enters 5
            5 -> {
                // If the list is not empty
                if(snowMenList.isNotEmpty())
                {
                    // Prompts user to enter id of snowman they want to delete and displays name and id of all snowmen
                    println("Enter ID of snowman you want to delete:\n")
                    for (snowman in snowMenList)
                    {
                        println(snowman.getNameAndID())
                    }
                    var snowmanId = 0
                    var foundSnowman = false
                    snowmanId = Integer.parseInt(readLine())

                    // Checks every snowman in the list to see if the id exists and if so deletes that snowman
                    for(snowman in snowMenList)
                    {
                        if(snowmanId == snowman.id)
                        {
                            println("Snowman ${snowman.name.toString()} deleted\n")
                            snowMenList.removeAt(snowmanId - 1)
                            foundSnowman = true
                            break
                        }
                    }

                    // If a snowman with the id is not found, prints out that none were found
                    if(!foundSnowman)
                    {
                        println("No snowman was found with that id.\n")
                    }
                }
                // If the list is empty, prints out that no snowmen exist
                else
                {
                    println("No snowman current exist.\n")
                }
            }
            // If the user enters 6
            6 -> {
                // Prompts user to enter id of snowman they want to modify and displays name and id of all snowmen
                println("Enter ID of snowman you want to modify:\n")
                var snowmanId = 0
                for (snowman in snowMenList)
                {
                    println(snowman.getNameAndID())
                }
                snowmanId = Integer.parseInt(readLine())

                // If the id the user entered is not in range, prompts user to enter valid id until one is entered
                while(snowmanId > snowMenList.size || snowmanId < 0)
                {
                    println("Please enter a valid id.\n")
                    snowmanId = Integer.parseInt(readLine())
                }

                // Sets snowmanToModify as snowman at the id the user entered from snowMenList and displays info
                val snowmanToModify = snowMenList[snowmanId - 1]
                println(snowMenList[snowmanId - 1].getAllInfo())

                // Prompts user to enter attribute they want to modify
                println("Enter the number of the attribute would you like to modify:\n" +
                        "1: Name\n" + "2: Has Top Hat\n" + "3: Date of Birth\n" + "4: Weight\n")
                var modifiedAttribute = Integer.parseInt(readLine())

                // If the attribute the user entered is not in range, prompts user to enter valid attribute until one is entered
                while(modifiedAttribute < 1 || modifiedAttribute > 4)
                {
                    println("Please enter a valid attribute.\n")
                    modifiedAttribute = Integer.parseInt(readLine())
                }

                // Has different outcomes depending on what user entered
                when (modifiedAttribute) {
                    // When user enters 1
                    1 -> {
                        // Prompts user to enter a new name and if nothing is entered leaves name as it is
                        println("Please enter the new name:")
                        val newName = readLine()?.takeIf { it.isNotBlank() } ?: snowmanToModify.name

                        // Updates snowman at the id the user entered
                        snowMenList[snowmanId - 1] = SnowMan(
                            snowmanToModify.id,
                            newName,
                            snowmanToModify.hasTopHat,
                            snowmanToModify.dateOfBirth,
                            snowmanToModify.weightKG
                        )
                        println("Name updated successfully.\n")
                    }
                    // When user enters 2
                    2 -> {
                        // Prompts user to enter whether or not the snowman has a tophat and if nothing is entered leaves it as it is
                        println("Does the snowman have a top hat? Enter 'true' or 'false':")
                        val newHasTopHat = readLine()?.toBooleanStrictOrNull() ?: snowmanToModify.hasTopHat

                        // Updates snowman at the id the user entered
                        snowMenList[snowmanId - 1] = SnowMan(
                            snowmanToModify.id,
                            snowmanToModify.name,
                            newHasTopHat,
                            snowmanToModify.dateOfBirth,
                            snowmanToModify.weightKG
                        )
                        println("Top Hat attribute updated successfully.\n")
                    }
                    // When user enters 3
                    3 -> {
                        // Prompts user to enter new date of birth and if nothing is entered leaves it as it is
                        println("Please enter the new date of birth (format: YYYY-MM-DD):")
                        val newDateOfBirth = try {
                            LocalDate.parse(readLine())
                        } catch (e: Exception) {
                            println("Invalid date format. Keeping the original date.")
                            snowmanToModify.dateOfBirth
                        }

                        // Updates snowman at the id the user entered
                        snowMenList[snowmanId - 1] = SnowMan(
                            snowmanToModify.id,
                            snowmanToModify.name,
                            snowmanToModify.hasTopHat,
                            newDateOfBirth,
                            snowmanToModify.weightKG
                        )
                        println("Date of Birth updated successfully.\n")
                    }
                    // When user enters 4
                    4 -> {
                        // Prompts user to enter new weight and if nothing is entered leaves it as it is
                        println("Please enter the new weight (in kilograms):")
                        val newWeight = readLine()?.toFloatOrNull() ?: snowmanToModify.weightKG

                        // Updates snowman at the id the user entered
                        snowMenList[snowmanId - 1] = SnowMan(
                            snowmanToModify.id,
                            snowmanToModify.name,
                            snowmanToModify.hasTopHat,
                            snowmanToModify.dateOfBirth,
                            newWeight
                        )
                        println("Weight updated successfully.\n")
                    }
                }
            }
            // If the user enters 9, breaks the loop
            9 -> {
                break
            }
            // If the user enters a number not listed, prompts the user to enter a valid option
            else -> println("Please enter a valid option\n")
        }

    }
}